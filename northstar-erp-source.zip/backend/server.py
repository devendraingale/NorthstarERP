#!/usr/bin/env python3
"""Northstar ERP: shared SQLite-backed multi-user web app (Python stdlib only)."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, unquote
import hashlib, hmac, json, math, os, re, secrets, sqlite3, time, uuid

ROOT = Path(__file__).resolve().parent.parent
WEB_ROOT = ROOT / 'frontend'
DB_PATH = Path(os.environ.get('NORTHSTAR_DB', ROOT / 'data' / 'northstar.sqlite3'))
PORT = int(os.environ.get('PORT', '8000'))
ENTITY = {
    'invoices': ('name,date,due,amount,status', 'name TEXT NOT NULL,date TEXT NOT NULL,due TEXT,amount REAL NOT NULL,status TEXT NOT NULL'),
    'sales': ('name,date,amount,status', 'name TEXT NOT NULL,date TEXT NOT NULL,amount REAL NOT NULL,status TEXT NOT NULL'),
    'purchases': ('name,date,amount,status', 'name TEXT NOT NULL,date TEXT NOT NULL,amount REAL NOT NULL,status TEXT NOT NULL'),
    'inventory': ('name,category,stock,price,status', 'name TEXT NOT NULL,category TEXT NOT NULL,stock INTEGER NOT NULL,price REAL NOT NULL,status TEXT NOT NULL'),
    'customers': ('name,email,phone,spent', 'name TEXT NOT NULL,email TEXT NOT NULL,phone TEXT NOT NULL,spent REAL NOT NULL DEFAULT 0'),
}

def connect():
    c = sqlite3.connect(DB_PATH, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA journal_mode=WAL')
    return c

def init_db():
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,name TEXT NOT NULL,password_hash TEXT NOT NULL,created_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS workspaces(id TEXT PRIMARY KEY,name TEXT NOT NULL,created_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS memberships(workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,role TEXT NOT NULL CHECK(role IN ('admin','member')),PRIMARY KEY(workspace_id,user_id));
        CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,expires_at INTEGER NOT NULL);
        ''')
        for name, (_, cols) in ENTITY.items():
            c.execute(f'CREATE TABLE IF NOT EXISTS {name}(id TEXT NOT NULL,workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,{cols},created_at INTEGER NOT NULL,PRIMARY KEY(workspace_id,id))')
        c.execute('CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires_at)')

def pw_hash(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    result = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 310000)
    return salt.hex() + ':' + result.hex()

def pw_ok(password, saved):
    try:
        salt, _ = saved.split(':', 1)
        return hmac.compare_digest(pw_hash(password, bytes.fromhex(salt)), saved)
    except Exception:
        return False

def token_hash(token):
    return hashlib.sha256(token.encode()).hexdigest()

def safe_record(row):
    d = dict(row)
    d.pop('workspace_id', None); d.pop('created_at', None)
    return d

class Handler(BaseHTTPRequestHandler):
    server_version = 'NorthstarERP/1.0'
    def log_message(self, fmt, *args):
        print('%s - %s' % (self.log_date_time_string(), fmt % args))
    def send_json(self, status, value=None):
        body = b'' if value is None else json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store'); self.end_headers()
        if body: self.wfile.write(body)
    def body(self):
        length = min(int(self.headers.get('Content-Length', '0')), 1_000_000)
        raw = self.rfile.read(length)
        try: return json.loads(raw or b'{}')
        except Exception: raise ValueError('Invalid JSON request.')
    def auth(self):
        token = self.headers.get('Authorization','')
        token = token[7:] if token.lower().startswith('bearer ') else ''
        if not token: return None
        with connect() as c:
            r = c.execute('SELECT u.id AS user_id,u.email,u.name,w.id AS workspace_id,w.name AS workspace_name,m.role FROM sessions s JOIN users u ON u.id=s.user_id JOIN workspaces w ON w.id=s.workspace_id JOIN memberships m ON m.user_id=u.id AND m.workspace_id=w.id WHERE s.token_hash=? AND s.expires_at>?',(token_hash(token),int(time.time()))).fetchone()
        return dict(r) if r else None
    def new_session(self, user_id, workspace_id):
        with connect() as c:
            role = c.execute('SELECT role FROM memberships WHERE user_id=? AND workspace_id=?',(user_id,workspace_id)).fetchone()
            user = c.execute('SELECT id,name,email FROM users WHERE id=?',(user_id,)).fetchone()
            ws = c.execute('SELECT id,name FROM workspaces WHERE id=?',(workspace_id,)).fetchone()
            if not role or not user or not ws: raise ValueError('Workspace is not available to this account.')
            token = secrets.token_urlsafe(40)
            c.execute('INSERT INTO sessions VALUES(?,?,?,?)',(token_hash(token),user_id,workspace_id,int(time.time())+7*86400))
            return {'token':token,'user':dict(user),'workspace':dict(ws),'role':role['role']}
    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/health': return self.send_json(200,{'ok':True,'database':'SQLite'})
        if path.startswith('/api/'):
            u=self.auth()
            if not u: return self.send_json(401,{'error':'Sign in to continue.'})
            if path == '/api/auth/me': return self.send_json(200,{'user':{'id':u['user_id'],'name':u['name'],'email':u['email']},'workspace':{'id':u['workspace_id'],'name':u['workspace_name']},'role':u['role']})
            if path == '/api/team':
                with connect() as c: rows=c.execute('SELECT u.name,u.email,m.role FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.workspace_id=? ORDER BY m.role,u.name',(u['workspace_id'],)).fetchall()
                return self.send_json(200,[dict(r) for r in rows])
            match=re.fullmatch(r'/api/records/([a-z]+)',path)
            if match:
                kind=match.group(1)
                if kind not in ENTITY: return self.send_json(404,{'error':'Unknown record type.'})
                with connect() as c: rows=c.execute(f'SELECT * FROM {kind} WHERE workspace_id=? ORDER BY created_at DESC',(u['workspace_id'],)).fetchall()
                return self.send_json(200,[safe_record(r) for r in rows])
            return self.send_json(404,{'error':'Route not found.'})
        asset = 'index.html' if path in ('/','') else path.lstrip('/')
        if asset not in {'index.html','manifest.webmanifest','sw.js','icon.svg'}: return self.send_error(404)
        target = WEB_ROOT / asset
        try:
            if not target.is_file(): raise FileNotFoundError
            content=target.read_bytes(); types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'}
            self.send_response(200);self.send_header('Content-Type',types.get(target.suffix,'application/octet-stream'));self.send_header('Content-Length',str(len(content)));self.end_headers();self.wfile.write(content)
        except (OSError,ValueError): self.send_error(404)
    def do_POST(self):
        path=urlparse(self.path).path
        try: data=self.body()
        except ValueError as e: return self.send_json(400,{'error':str(e)})
        try:
            if path == '/api/auth/register':
                name=(data.get('name') or '').strip();email=(data.get('email') or '').strip().lower();password=data.get('password') or '';wsname=(data.get('workspaceName') or '').strip()
                if not name or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or len(password)<10 or not wsname: return self.send_json(400,{'error':'Enter your name, valid email, workspace name, and password of at least 10 characters.'})
                uid,wid=str(uuid.uuid4()),str(uuid.uuid4());now=int(time.time())
                with connect() as c:
                    c.execute('INSERT INTO users VALUES(?,?,?,?,?)',(uid,email,name,pw_hash(password),now));c.execute('INSERT INTO workspaces VALUES(?,?,?)',(wid,wsname,now));c.execute('INSERT INTO memberships VALUES(?,?,?)',(wid,uid,'admin'))
                return self.send_json(201,self.new_session(uid,wid))
            if path == '/api/auth/login':
                email=(data.get('email') or '').strip().lower(); password=data.get('password') or ''
                with connect() as c:
                    user=c.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
                    if not user or not pw_ok(password,user['password_hash']): return self.send_json(401,{'error':'Email or password is incorrect.'})
                    rows=c.execute('SELECT w.id,w.name,m.role FROM memberships m JOIN workspaces w ON w.id=m.workspace_id WHERE m.user_id=? ORDER BY w.created_at',(user['id'],)).fetchall()
                if not rows: return self.send_json(403,{'error':'No workspace is assigned to this account.'})
                chosen=next((r for r in rows if r['id']==data.get('workspaceId')),None)
                if len(rows)>1 and not chosen: return self.send_json(200,{'chooseWorkspace':True,'workspaces':[{'id':r['id'],'name':r['name'],'role':r['role']} for r in rows]})
                return self.send_json(200,self.new_session(user['id'],(chosen or rows[0])['id']))
            u=self.auth()
            if not u: return self.send_json(401,{'error':'Sign in to continue.'})
            if path == '/api/team/invite':
                if u['role']!='admin': return self.send_json(403,{'error':'Only admins can add workspace members.'})
                email=(data.get('email') or '').strip().lower()
                with connect() as c:
                    member=c.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()
                    if not member: return self.send_json(404,{'error':'Ask this person to register before adding them.'})
                    c.execute("INSERT OR IGNORE INTO memberships VALUES(?,?, 'member')",(u['workspace_id'],member['id']))
                return self.send_json(201,{'ok':True})
            match=re.fullmatch(r'/api/records/([a-z]+)',path)
            if match:
                kind=match.group(1)
                if kind not in ENTITY: return self.send_json(404,{'error':'Unknown record type.'})
                fields=ENTITY[kind][0].split(',')
                if any(data.get(f) is None or data.get(f)=='' for f in fields): return self.send_json(400,{'error':'Complete all required fields.'})
                try:
                    for field in ('amount','price','spent'):
                        if field in fields:
                            number=float(data[field])
                            if not math.isfinite(number) or number < 0: raise ValueError()
                            data[field]=number
                    if 'stock' in fields:
                        data['stock']=int(data['stock'])
                        if data['stock'] < 0: raise ValueError()
                    if kind=='invoices' and data.get('status') not in {'Pending','Paid','Overdue'}: raise ValueError()
                    if kind=='sales' and data.get('status') not in {'Completed','Pending'}: raise ValueError()
                    if kind=='purchases' and data.get('status') not in {'Received','Pending'}: raise ValueError()
                    if kind=='inventory' and data.get('status') not in {'In stock','Low stock','Out of stock'}: raise ValueError()
                except (ValueError,TypeError): return self.send_json(400,{'error':'Enter valid non-negative amounts and stock values.'})
                rid=data.get('id') or str(uuid.uuid4()); now=int(time.time()); cols=['id','workspace_id']+fields; vals=[rid,u['workspace_id']]+[data[f] for f in fields]+[now]
                with connect() as c: c.execute(f"INSERT INTO {kind}({','.join(cols)},created_at) VALUES({','.join('?' for _ in vals)})",vals)
                return self.send_json(201,{'id':rid,**{f:data[f] for f in fields}})
            return self.send_json(404,{'error':'Route not found.'})
        except sqlite3.IntegrityError as e:
            msg='Email is already registered.' if 'users.email' in str(e) else 'A record with that ID already exists.'
            return self.send_json(409,{'error':msg})
        except Exception as e:
            print('Request error:',repr(e));return self.send_json(500,{'error':'The server could not complete that request.'})
    def do_DELETE(self):
        u=self.auth()
        if not u: return self.send_json(401,{'error':'Sign in to continue.'})
        m=re.fullmatch(r'/api/records/([a-z]+)/([^/]+)',urlparse(self.path).path)
        if not m or m.group(1) not in ENTITY: return self.send_json(404,{'error':'Route not found.'})
        kind,rid=m.group(1),unquote(m.group(2))
        with connect() as c: cur=c.execute(f'DELETE FROM {kind} WHERE id=? AND workspace_id=?',(rid,u['workspace_id']))
        return self.send_json(204 if cur.rowcount else 404, None if cur.rowcount else {'error':'Record not found.'})

if __name__ == '__main__':
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    init_db()
    print(f'Northstar ERP is running at http://localhost:{PORT} (SQLite: {DB_PATH})')
    ThreadingHTTPServer(('0.0.0.0',PORT),Handler).serve_forever()
